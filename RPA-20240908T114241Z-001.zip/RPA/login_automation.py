from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Set up the WebDriver
driver = webdriver.Edge()

# URL of the login page
login_url = 'https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26useRedirectOnSuccess%3D1%26signIn%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0'

# Credentials
username = '8250740865'
password = 'sayak123'

try:
    # Navigate to the login page
    driver.get(login_url)
    time.sleep(2)  # Wait for the page to load

    # Step 1: Enter the username
    username_input = driver.find_element(By.ID, 'ap_email')
    username_input.send_keys(username)
    username_input.send_keys(Keys.RETURN)
    time.sleep(2)  # Wait for the password page to load

    # Step 2: Enter the password
    password_input = driver.find_element(By.ID, 'ap_password')
    password_input.send_keys(password)
    password_input.send_keys(Keys.RETURN)
    time.sleep(5)  # Wait for the login process to complete

    # Optionally, you can verify the login by checking for some element on the dashboard page
    if 'Hello, ' in driver.page_source:
        print('Login successful')
    else:
        print('Login failed')

    # Navigate to a repository to download
    #driver.get(repo_url)
    #time.sleep(2)  # Wait for the page to load

    # Click the "Code" button to reveal the download options
    #driver.find_element(By.XPATH, "//summary[contains(@aria-label, 'Code')]").click()
    #time.sleep(2)  # Wait for the dropdown to appear

    # Click the "Download ZIP" link
    #driver.find_element(By.XPATH, "//a[contains(@href, '/archive/refs/heads/main.zip')]").click()
    #time.sleep(10)  # Wait for the download to complete

finally:
    # Close the WebDriver
    driver.quit()
